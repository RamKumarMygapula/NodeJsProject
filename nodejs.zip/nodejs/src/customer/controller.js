const pool = require ('../../db');

const getcustomer = (req,res)=>{
    pool.query("SELECT * from customer", (error, results)=>{
        if (error) throw error;
        res.status(200).json(results.rows);
    });
};
const getcustomerlocation=(req,res)=>{
    const location=parseInt(req.params.location);
    pool.query("SELECT * FROM customer WHERE location = $1",[location],(error,results)=>{
        if(error) throw error;
        res.status(200).json(results.rows);
    });
};
const addcustomer=(req,res)=>{
    const {sno , name ,age ,phone, location, created_at} =req.body;
    pool.query("INSERT INTO customer(sno, name, age, phone, location, created_at) VALUES($1,$2,$3,$4,$5,$6)",[sno,name,age,phone,location,created_at],(error,results)=>{
        if(error) throw error;
        res.status(200).send("successfully created");
    });
};

module.exports={
    getcustomer,
    getcustomerlocation,
    addcustomer,
};