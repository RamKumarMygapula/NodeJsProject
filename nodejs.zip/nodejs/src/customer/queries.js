const getcustomer= "SELECT * FROM customer";
const getcustomerlocation = "SELECT * FROM customer WHERE location= $1";
const addcustomer="INSERT INTO customer (sno,name,age,phone,location,created_at) VALUES ($1,$2,$3,$4,$5,$6)";
module.export ={
    getcustomer,
    getcustomerlocation,
    addcustomer,
}