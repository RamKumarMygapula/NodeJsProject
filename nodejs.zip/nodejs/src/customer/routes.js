const {Router} = require ('express');
const controller=require ('./controller');
const router = Router();
router.get("/", controller.getcustomer);
router.post("/",controller.addcustomer);
router.get("/:location",controller.getcustomerlocation);
module.exports = router;