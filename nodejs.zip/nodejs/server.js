const express = require('express');
const customerRoutes=require('./src/customer/routes');
const app = express();
const port = 3000;
app.use(express.json());
app.get("/",(req, res)=>{
    res.send('hello');
    res.end();
});
app.use("/api/v1/customer", customerRoutes);

app.listen(port, ()=> console.log("hello"));
